from django.contrib import admin

from .models import student_data

admin.site.register(student_data)
