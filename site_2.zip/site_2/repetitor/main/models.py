from django.db import models

class student_data(models.Model):
    login = models.CharField('Логин', max_length=50)
    password = models.CharField('Пароль', max_length=50)


    def __str__(self):
        return self.login

    class Meta:
        verbose_name = 'Логин/Пароль'
        verbose_name_plural = 'Логины/Пароли'




