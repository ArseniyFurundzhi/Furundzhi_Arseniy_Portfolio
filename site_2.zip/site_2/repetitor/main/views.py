from django.shortcuts import render, redirect
from django.http import HttpResponse

from .forms import *
from .models import student_data




# Create your views here.

def index(request):
    login = ''
    password = ''
    auth_message = ''
    email_message = ''
    auth_error_check = False
    email_error_check = False
    if request.method == 'POST':
        users = student_data.objects.all()

        form = LoginForm(request.POST)
        if form.is_valid():
            login = form.cleaned_data.get("login")
            password = form.cleaned_data.get("password")

            for el in users:
                if el.login == login and el.password == password:
                    match el.login:
                        case 'lisa@mail.ru':
                            return redirect('students_lisa')
                        case 'mihail@mail.ru':
                            return redirect('students_mihail')
                        case 'artem@mail.ru':
                            return redirect('students_artem')
                        case 'maria@mail.ru':
                            return redirect('students_maria')
                        case 'sasha@mail.ru':
                            return redirect('students_sasha')
                        case 'makarshitov@gmail.com':
                            return redirect('students')
                        case _:
                            return redirect('loading')
            else:
                auth_error_check = True
                auth_message = 'Неверный логин или пароль'
        else:
            email_error_check = True
            email_message = 'Хмм, это не похоже на электронную почту.'

    else:
        form = LoginForm()



    context = {
        'form': form,
        'auth_message': auth_message,
        'auth_error_check': auth_error_check,
        'email_message': email_message,
        'email_error_check': email_error_check,
    }

    return render(request, 'main/index.html', context)

def sign_up(request):
    pass_message = ''
    email_message = ''
    pass_error_check = False
    email_error_check = False

    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            try:
                student_data.objects.create(**form.cleaned_data)
                return redirect('home')
            except:
                form.add_error(None, 'Ошибка регистрации')
        else:
            email_error_check = True
            email_message = 'Хмм, это не похоже на электронную почту.'
    else:
        form = LoginForm()

    context = {
        'form': form,
        'email_message': email_message,
        'email_error_check': email_error_check,
        'pass_message': pass_message,
        'pass_error_check': pass_error_check,
    }

    return render(request, 'main/sign_up.html', context)

def in_progress(request):
    return render(request, 'main/in_progress.html')




