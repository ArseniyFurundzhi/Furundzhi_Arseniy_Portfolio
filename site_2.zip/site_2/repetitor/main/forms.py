from django import forms
from .models import *



class LoginForm(forms.Form):
    login = forms.EmailField(widget=forms.TextInput(attrs={'placeholder': 'mail@example.com', 'class': 'login__input'}), label="")
    password = forms.CharField(widget=forms.PasswordInput(attrs={'class': 'password__input'}), label="")