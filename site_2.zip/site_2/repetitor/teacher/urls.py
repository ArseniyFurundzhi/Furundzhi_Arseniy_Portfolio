from django.urls import path, include
from . import views
from django.contrib.auth import views as authViews

urlpatterns = [
    path('', views.teacher),
    path('students', views.teacher_students, name='students'),
    path('students/lisa', views.teacher_st_lisa, name='teacher_st_lisa'),
    path('students/sasha', views.teacher_st_sasha, name='teacher_st_sasha'),
    path('students/artem', views.teacher_st_artem, name='teacher_st_artem'),
    path('students/maria', views.teacher_st_maria, name='teacher_st_maria'),
    path('students/mihail', views.teacher_st_mihail, name='teacher_st_mihail'),
    path('today', views.teacher_today, name='today'),
    path('schedule', views.teacher_schedule, name='schedule'),
    path('exit/', authViews.LogoutView.as_view(next_page='/'), name='exit'),
]