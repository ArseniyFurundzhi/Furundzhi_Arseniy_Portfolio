from django.shortcuts import render, redirect
from django.http import HttpResponse

from django.template.defaulttags import register
import datetime

from students.models import students_information
from students.models import useful_information

def homework_date(info):
    days = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс']
    week_day_str = info.week_day

    lesson_days = []
    s = ''
    for i in week_day_str:
        if i == ' ':
            lesson_days.append(s)
            s = ''
        else:
            s += i
    lesson_days.append(s)

    lesson_day_mass = []
    for i in range(len(lesson_days)):
        for day in days:
            if lesson_days[i] == day:
                lesson_day_num = days.index(day)
                lesson_day_mass.append(lesson_day_num)

    current_date = datetime.datetime.today().weekday()
    if len(lesson_day_mass) == 1:
        if current_date > lesson_day_mass[0]:
            days_plus = 7 - current_date + lesson_day_mass[0]
        else:
            days_plus = lesson_day_mass[0] - current_date

        day1 = (datetime.datetime.now() + datetime.timedelta(days=abs(days_plus))).strftime("%d. %m")
        day2 = (datetime.datetime.now() + datetime.timedelta(days=days_plus - 7)).strftime("%d. %m")
        day3 = (datetime.datetime.now() + datetime.timedelta(days=days_plus - 14)).strftime("%d. %m")

    elif len(lesson_day_mass) == 2:
        if current_date > lesson_day_mass[0]:
            days_plus1 = 7 - current_date + lesson_day_mass[0]
        else:
            days_plus1 = lesson_day_mass[0] - current_date
        if current_date > lesson_day_mass[1]:
            days_plus2 = 7 - current_date + lesson_day_mass[1]
        else:
            days_plus2 = lesson_day_mass[1] - current_date

        day1_1 = (datetime.datetime.now() + datetime.timedelta(days=abs(days_plus1))).strftime("%d. %m")
        day1_2 = (datetime.datetime.now() + datetime.timedelta(days=abs(days_plus2))).strftime("%d. %m")
        day2 = (datetime.datetime.now() + datetime.timedelta(days=days_plus2 - 7)).strftime("%d. %m")
        day3 = (datetime.datetime.now() + datetime.timedelta(days=days_plus1 - 7)).strftime("%d. %m")

        if days_plus1 > days_plus2:
            day1 = day1_2

            n = day2
            day2 = day3
            day3 = n
        else:
            day1 = day1_1

    final_days_mas = [day1, day2, day3]
    return final_days_mas

def date(info):
    week_day_str = info.week_day
    lesson_time_str = info.time

    lesson_days = []
    s = ''
    for i in week_day_str:
        if i == ' ':
            lesson_days.append(s)
            s = ''
        else:
            s += i
    lesson_days.append(s)

    s = ''
    lesson_time = []
    for i in lesson_time_str:
        if i == ' ':
            lesson_time.append(s)
            s = ''
        else:
            s += i
    lesson_time.append(s)

    datetime_mas = []
    day_time_mas = []
    for i in range (len(lesson_time)):
        day_time_mas.append(lesson_days[i])
        day_time_mas.append(lesson_time[i])
        datetime_mas.append(day_time_mas)
        day_time_mas = []

    return datetime_mas

def today_lessons(info):
    days = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс']
    days2 = ['Понедельник', 'Вторник', 'Среда', 'Четверг', 'Пятница', 'Суббота', 'Воскресенье']
    current_time = str(datetime.datetime.now().time())
    current_time_hours = ''
    for i in range (len(current_time)):
        if current_time[i] != ':':
            current_time_hours += current_time[i]
        else:
            break

    current_time_hours = int(current_time_hours)

    lessons_mas = []
    current_date = datetime.datetime.today().weekday()
    today_day = days2[current_date]
    lessons_mas.append(today_day)
    for el in info:
        weekday_str = ''
        weekday_mas = []

        for i in range (len(el.week_day)):
            if el.week_day[i] != ' ':
                weekday_str += el.week_day[i]
            else:
                weekday_mas.append(weekday_str)
                weekday_str = ''
        weekday_mas.append(weekday_str)

        time_str = ''
        time_mas = []
        for i in range (len(el.time)):
            if el.time[i] != ' ':
                time_str += el.time[i]
            else:
                time_mas.append(time_str)
                time_str = ''
        time_mas.append(time_str)

        lesson_day_mass = []
        for i in range(len(weekday_mas)):
            for day in days:
                if weekday_mas[i] == day:
                    lesson_day_num = days.index(day)
                    lesson_day_mass.append(lesson_day_num)

        lesson_mas = []
        k = 0
        for i in lesson_day_mass:
            if i == current_date:
                k = 1
                ind = lesson_day_mass.index(i)
                lesson_time = time_mas[ind]
                if int(lesson_time[6:8]) > current_time_hours:
                    lesson_mas.append(el.name)
                    lesson_mas.append(el.subject)
                    lesson_mas.append(lesson_time)
                    lessons_mas.append(lesson_mas)
                    lesson_mas = []

    for i in range(len(lessons_mas)):
        for j in range(len(lessons_mas) - i - 1):
            time1 = ''
            time2 = ''

            time1 += lessons_mas[j][2][6:8]
            time2 += lessons_mas[j+1][2][6:8]

            if time1 > time2:
                n = lessons_mas[j]
                lessons_mas[j] = lessons_mas[j + 1]
                lessons_mas[j + 1] = n

    if len(lessons_mas) == 1:
        if k==0:
            lessons_mas.append('Сегодня нет занятий')
        else:
            lessons_mas.append('Сегодня больше нет занятий')

    return lessons_mas

def get_schedule(info):
    days = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс']
    scheduele_days = [['Понедельник'], ['Вторник'], ['Среда'], ['Четверг'], ['Пятница'], ['Суббота'], ['Воскресенье']]



    for el in info:
        weekday_str = ''
        weekday_mas = []

        for i in range(len(el.week_day)):
            if el.week_day[i] != ' ':
                weekday_str += el.week_day[i]
            else:
                weekday_mas.append(weekday_str)
                weekday_str = ''
        weekday_mas.append(weekday_str)

        time_str = ''
        time_mas = []
        for i in range(len(el.time)):
            if el.time[i] != ' ':
                time_str += el.time[i]
            else:
                time_mas.append(time_str)
                time_str = ''
        time_mas.append(time_str)

        for i in range(len(weekday_mas)):
            for day in days:
                if day == weekday_mas[i]:
                    student_info_mas = []
                    day_num = days.index(day)
                    student_info_mas.append(time_mas[i])
                    student_info_mas.append(el.name)
                    student_info_mas.append(el.subject)

                    scheduele_days[day_num].append(student_info_mas)


    for el in scheduele_days:
        if len(el) == 1:
            el.append('Нет занятий')
        for i in range(1,len(el)):
            for j in range(1,len(el) - i):
                if j != 0:
                    time1 = ''
                    time2 = ''

                    time1 += el[j][0][6:8]
                    time2 += el[j + 1][0][6:8]

                    if time1 > time2:
                        n = el[j]
                        el[j] = el[j + 1]
                        el[j + 1] = n

    return scheduele_days;

def teacher(request):
    return redirect('students')

def teacher_students(request):
    menu_items = [True, False, False]

    links_mas = [['students/lisa', 'Лиза'], ['students/mihail', 'Михаил'], ['students/sasha', 'Саша'], ['students/artem', 'Артём'], ['students/maria', 'Мария']]
    info = students_information.objects.all()



    context = {
        'menu_items': menu_items,
        'info': info,
        'links_mas': links_mas,
    }

    return render(request, 'teacher/teach_students.html', context)

def teacher_today(request):
    menu_items = [False, True, False]

    links_mas = [['students/lisa', 'Лиза'], ['students/mihail', 'Михаил'], ['students/sasha', 'Саша'], ['students/artem', 'Артём'], ['students/maria', 'Мария']]
    info = students_information.objects.all()

    lessons_mas = today_lessons(info)

    context = {
        'menu_items': menu_items,
        'info': info,
        'lessons_mas': lessons_mas,
        'links_mas': links_mas,
    }

    return render(request, 'teacher/teach_today.html', context)

def teacher_schedule(request):
    menu_items = [False, False, True]

    links_mas = [['students/lisa', 'Лиза'], ['students/mihail', 'Михаил'], ['students/sasha', 'Саша'], ['students/artem', 'Артём'], ['students/maria', 'Мария']]
    info = students_information.objects.all()

    schedule_mas = get_schedule(info)

    days = [['Понедельник'], ['Вторник'], ['Среда'], ['Четверг'], ['Пятница'], ['Суббота'], ['Воскресенье']]
    current_date = int(datetime.datetime.today().weekday())
    current_day = days[current_date][0]

    context = {
        'menu_items': menu_items,
        'info': info,
        'schedule_mas': schedule_mas,
        'links_mas': links_mas,
        'current_day': current_day,
    }

    return render(request, 'teacher/teach_schedule.html', context)

def teacher_st_lisa(request):
    info = students_information.objects.all()
    sources = useful_information.objects.all()

    menu_items = [True, False, False]

    for el in info:
        if el.name == 'Лиза':
            st_info = el

    homework_day = homework_date(st_info)

    sources_dict = []
    sources_dict_source = []
    for el in sources:
        if el.name == 'Лиза':
            sources_dict_source.append(el.source_name)
            sources_dict_source.append(el.source_link)
            sources_dict.append(sources_dict_source)
            sources_dict_source = []


    date_time = date(st_info)


    index_mas = []
    for i in range(len(date_time[0])):
        index_mas.append(i)

    context = {
        'date_time': date_time,
        'info': st_info,
        'index_mas': index_mas,
        'menu_items': menu_items,
        'sources_dict': sources_dict,
        'homework_day': homework_day,
    }

    return render(request, 'teacher/teach_lisa.html', context)

def teacher_st_sasha(request):
    info = students_information.objects.all()
    sources = useful_information.objects.all()

    menu_items = [True, False, False]

    for el in info:
        if el.name == 'Саша':
            st_info = el

    homework_day = homework_date(st_info)

    sources_dict = []
    sources_dict_source = []
    for el in sources:
        if el.name == 'Саша':
            sources_dict_source.append(el.source_name)
            sources_dict_source.append(el.source_link)
            sources_dict.append(sources_dict_source)
            sources_dict_source = []

    date_time = date(st_info)

    index_mas = []
    for i in range(len(date_time[0])):
        index_mas.append(i)

    context = {
        'date_time': date_time,
        'info': st_info,
        'index_mas': index_mas,
        'menu_items': menu_items,
        'sources_dict': sources_dict,
        'homework_day': homework_day,
    }

    return render(request, 'teacher/teach_sasha.html', context)

def teacher_st_mihail(request):
    info = students_information.objects.all()
    sources = useful_information.objects.all()

    menu_items = [True, False, False]

    for el in info:
        if el.name == 'Михаил':
            st_info = el

    homework_day = homework_date(st_info)

    sources_dict = []
    sources_dict_source = []
    for el in sources:
        if el.name == 'Михаил':
            sources_dict_source.append(el.source_name)
            sources_dict_source.append(el.source_link)
            sources_dict.append(sources_dict_source)
            sources_dict_source = []

    date_time = date(st_info)

    index_mas = []
    for i in range(len(date_time[0])):
        index_mas.append(i)

    context = {
        'date_time': date_time,
        'info': st_info,
        'index_mas': index_mas,
        'menu_items': menu_items,
        'sources_dict': sources_dict,
        'homework_day': homework_day,
    }

    return render(request, 'teacher/teach_sasha.html', context)

def teacher_st_artem(request):
    info = students_information.objects.all()
    sources = useful_information.objects.all()

    menu_items = [True, False, False]

    for el in info:
        if el.name == 'Артём':
            st_info = el

    homework_day = homework_date(st_info)

    sources_dict = []
    sources_dict_source = []
    for el in sources:
        if el.name == 'Артём':
            sources_dict_source.append(el.source_name)
            sources_dict_source.append(el.source_link)
            sources_dict.append(sources_dict_source)
            sources_dict_source = []

    date_time = date(st_info)

    index_mas = []
    for i in range(len(date_time[0])):
        index_mas.append(i)

    context = {
        'date_time': date_time,
        'info': st_info,
        'index_mas': index_mas,
        'menu_items': menu_items,
        'sources_dict': sources_dict,
        'homework_day': homework_day,
    }

    return render(request, 'teacher/teach_artem.html', context)

def teacher_st_maria(request):
    info = students_information.objects.all()
    sources = useful_information.objects.all()

    menu_items = [True, False, False]

    for el in info:
        if el.name == 'Мария':
            st_info = el

    homework_day = homework_date(st_info)

    sources_dict = []
    sources_dict_source = []
    for el in sources:
        if el.name == 'Мария':
            sources_dict_source.append(el.source_name)
            sources_dict_source.append(el.source_link)
            sources_dict.append(sources_dict_source)
            sources_dict_source = []

    date_time = date(st_info)

    index_mas = []
    for i in range(len(date_time[0])):
        index_mas.append(i)

    context = {
        'date_time': date_time,
        'info': st_info,
        'index_mas': index_mas,
        'menu_items': menu_items,
        'sources_dict': sources_dict,
        'homework_day': homework_day,
    }

    return render(request, 'teacher/teach_maria.html', context)