from django.db import models

class student_data(models.Model):
    name = models.CharField('Название', max_length=50)
    board = models.CharField('Ссылка на доску', max_length=100)
    date = models.DateField('Дата')
    time = models.TimeField('Время')
    homework = models.CharField('ДЗ', max_length=50)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = 'Информация о студенте'
        verbose_name_plural = 'Информация о студентах'

class student_info(models.Model):
    name = models.CharField('Название', max_length=50)
    platform = models.CharField('Платформа', max_length=50)
    nickname = models.CharField('Ник', max_length=50)
    board_name = models.CharField('Название доски', max_length=100)
    board_link = models.CharField('Ссылка на доску', max_length=100)
    time = models.CharField('Время', max_length=50)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = 'Инфа о студенте'
        verbose_name_plural = 'Инфа о студентах'

class student_information(models.Model):
    name = models.CharField('Название', max_length=50)
    platform = models.CharField('Платформа', max_length=50)
    nickname = models.CharField('Ник', max_length=50)
    board_name = models.CharField('Название доски', max_length=100)
    board_link = models.CharField('Ссылка на доску', max_length=100)
    week_day = models.CharField('День недели', max_length=50)
    time = models.CharField('Время', max_length=50)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = 'ИнформациЯ о студенте'
        verbose_name_plural = 'ИнформациЯ о студентах'

class useful_info(models.Model):
    name = models.CharField('Имя ученика', max_length=50)
    source_name = models.CharField('Название источника', max_length=100)
    source_link = models.CharField('Ссылка на источник', max_length=100)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = 'Полезная инфа'
        verbose_name_plural = 'Полезная информация'



class students_information(models.Model):
    name = models.CharField('Имя ученика', max_length=50)
    par_name = models.CharField('Имя родителя', max_length=50)
    st_phone = models.CharField('Номер ученика', max_length=20)
    par_phone = models.CharField('Номер родителя', max_length=20)
    grade = models.CharField('Класс', max_length=50)
    subject = models.CharField('Предмет', max_length=50)
    platform = models.CharField('Платформа', max_length=50)
    nickname = models.CharField('Ник учителя', max_length=50)
    st_nickname = models.CharField('Ник ученика', max_length=50)
    board_name = models.CharField('Название доски', max_length=100)
    board_link = models.CharField('Ссылка на доску', max_length=100)
    week_day = models.CharField('День недели', max_length=50)
    time = models.CharField('Время', max_length=50)
    price = models.CharField('Цена', max_length=50)


    def __str__(self):
        return self.name

    class Meta:
        verbose_name = 'Инфoрмация о студенте'
        verbose_name_plural = 'Инфoрмация о студентах'

class useful_information(models.Model):
    name = models.CharField('Имя ученика', max_length=50)
    source_name = models.CharField('Название источника', max_length=100)
    source_link = models.CharField('Ссылка на источник', max_length=1000)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = 'Полезная инфа'
        verbose_name_plural = 'Полезная информация'

class home_works(models.Model):
    name = models.CharField('Имя ученика', max_length=50)
    date = models.CharField('Дата', max_length=20)
    source_link = models.CharField('Ссылка на источник', max_length=1000)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = 'Домашку'
        verbose_name_plural = 'Домашки'

