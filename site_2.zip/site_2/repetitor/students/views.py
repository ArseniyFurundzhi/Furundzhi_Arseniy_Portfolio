from django.shortcuts import render

# Create your views here.
from .models import students_information
from .models import home_works

from django.template.defaulttags import register
import datetime




def students(request):
    return 0

def lesson_date(info):
    days = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс']
    week_day_str = info.week_day
    lesson_time_str = info.time

    lesson_days = []
    s = ''
    for i in week_day_str:
        if i == ' ':
            lesson_days.append(s)
            s = ''
        else:
            s += i
    lesson_days.append(s)

    s = ''
    lesson_time = []
    for i in lesson_time_str:
        if i == ' ':
            lesson_time.append(s)
            s = ''
        else:
            s += i
    lesson_time.append(s)


    lesson_day_mass = []
    for i in range(len(lesson_days)):
        for day in days:
            if lesson_days[i] == day:
                lesson_day_num = days.index(day)
                lesson_day_mass.append(lesson_day_num)

    current_date = datetime.datetime.today().weekday()
    if len(lesson_day_mass) == 1:
        if current_date > lesson_day_mass[0]:
            days_plus = 7 - current_date + lesson_day_mass[0]
        else:
            days_plus = lesson_day_mass[0] - current_date

        day1 = (datetime.datetime.now() + datetime.timedelta(days=abs(days_plus))).strftime("%d.%m")
        day2 = (datetime.datetime.now() + datetime.timedelta(days=abs(days_plus + 7))).strftime("%d.%m")
        day3 = (datetime.datetime.now() + datetime.timedelta(days=abs(days_plus + 14))).strftime("%d.%m")
        day4 = (datetime.datetime.now() + datetime.timedelta(days=abs(days_plus + 21))).strftime("%d.%m")
        day5 = (datetime.datetime.now() + datetime.timedelta(days=days_plus - 7)).strftime("%d.%m")
        day6 = (datetime.datetime.now() + datetime.timedelta(days=days_plus - 14)).strftime("%d.%m")

        double = lesson_time[0]
        lesson_time.append(double)
    elif len(lesson_day_mass) == 2:
        if current_date > lesson_day_mass[0]:
            days_plus1 = 7 - current_date + lesson_day_mass[0]
        else:
            days_plus1 = lesson_day_mass[0] - current_date
        if current_date > lesson_day_mass[1]:
            days_plus2 = 7 - current_date + lesson_day_mass[1]
        else:
            days_plus2 = lesson_day_mass[1] - current_date

        day1 = (datetime.datetime.now() + datetime.timedelta(days=abs(days_plus1))).strftime("%d.%m")
        day2 = (datetime.datetime.now() + datetime.timedelta(days=abs(days_plus2))).strftime("%d.%m")
        day3 = (datetime.datetime.now() + datetime.timedelta(days=abs(days_plus1 + 7))).strftime("%d.%m")
        day4 = (datetime.datetime.now() + datetime.timedelta(days=abs(days_plus2 + 7))).strftime("%d.%m")
        day5 = (datetime.datetime.now() + datetime.timedelta(days=days_plus2 - 7)).strftime("%d.%m")
        day6 = (datetime.datetime.now() + datetime.timedelta(days=days_plus1 - 7)).strftime("%d.%m")

        if days_plus1 > days_plus2:
            n=day1
            day1=day2
            day2=n
            n = day3
            day3 = day4
            day4 = n
            n=lesson_time[0]
            lesson_time[0] = lesson_time[1]
            lesson_time[1] = n

            n = day5
            day5 = day6
            day6 = n



    final_days_mas = [day1, day2, day3, day4, day5, day6]
    date_time = [lesson_time, final_days_mas]
    return date_time

def students_lisa(request):
    info = students_information.objects.all()

    for el in info:
        if el.name == 'Лиза':
            st_info = el

    date_time = lesson_date(st_info)

    context = {
        'info': st_info,
        'date_time': date_time,
    }

    return render(request, 'students/student_lisa.html', context)

def students_mihail(request):
    info = students_information.objects.all()

    for el in info:
        if el.name == 'Михаил':
            st_info = el

    date_time = lesson_date(st_info)

    context = {
        'info': st_info,
        'date_time': date_time,
    }
    return render(request, 'students/student_mihail.html', context)

def students_artem(request):
    info = students_information.objects.all()

    for el in info:
        if el.name == 'Артём':
            st_info = el

    date_time = lesson_date(st_info)

    context = {
        'info': st_info,
        'date_time': date_time,
    }

    return render(request, 'students/student_artem.html', context)

def students_maria(request):
    info = students_information.objects.all()

    for el in info:
        if el.name == 'Мария':
            st_info = el

    date_time = lesson_date(st_info)

    context = {
        'info': st_info,
        'date_time': date_time,
    }

    return render(request, 'students/student_maria.html', context)

def students_sasha(request):
    info = students_information.objects.all()
    sources = home_works.objects.all()

    for el in info:
        if el.name == 'Саша':
            st_info = el

    date_time = lesson_date(st_info)

    sources_dict = []
    sources_dict_source = []
    for el in sources:
        if el.name == 'Саша':
            sources_dict_source.append(el.name)
            if datetime.datetime.today().strftime("%d.%m") == el.date:
                sources_dict_source.append(el.source_link)
                sources_dict.append(sources_dict_source)
                sources_dict_source = []
            if (lesson_date(st_info))[1][4] == el.date:
                sources_dict[0].append(el.source_link)
            if (lesson_date(st_info))[1][5] == el.date:
                sources_dict[0].append(el.source_link)
        context = {
            'info': st_info,
            'date_time': date_time,
            'sources_dict': sources_dict,
    }

    return render(request, 'students/student_sasha.html', context)