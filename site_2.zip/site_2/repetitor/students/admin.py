from django.contrib import admin
from .models import *



admin.site.register(students_information)
admin.site.register(useful_information)
admin.site.register(home_works)





