from django.urls import path, include
from . import views
from django.contrib.auth import views as authViews

urlpatterns = [
    path('', views.students),
    path('exit/', authViews.LogoutView.as_view(next_page='/'), name='exit'),
    path('students_lisa', views.students_lisa, name='students_lisa'),
    path('students_mihail', views.students_mihail, name='students_mihail'),
    path('students_artem', views.students_artem, name='students_artem'),
    path('students_maria', views.students_maria, name='students_maria'),
    path('students_sasha', views.students_sasha, name='students_sasha'),
]